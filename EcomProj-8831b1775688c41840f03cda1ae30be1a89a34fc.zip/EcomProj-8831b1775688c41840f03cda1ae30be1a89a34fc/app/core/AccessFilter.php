<?php
namespace app\core;

interface AccessFilter
{

	public function redirected();

}