<?php
session_start();
require ('app/core/App.php');
require ('app/core/Controller.php');
require ('app/core/autoload.php');
require_once ('vendor/autoload.php');
// require ('app/core/i18n.php');
//future inclusion for Model
