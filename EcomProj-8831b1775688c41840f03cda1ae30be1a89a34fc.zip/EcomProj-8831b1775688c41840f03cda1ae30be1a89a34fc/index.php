<?php
use app\core\App;
require('app/core/init.php');

new App();